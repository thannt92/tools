#ifndef _JIM_CONFIG_H
#define _JIM_CONFIG_H
#define HAVE_LONG_LONG 1
/* #undef JIM_UTF8 */
#define JIM_VERSION 76
#endif
